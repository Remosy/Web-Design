<?php

$action = $_GET['Action'];
$input = $_GET['User_Input'];

if($action=="Connect"){Connect();}

function Distrubutor(){
		
}

function Connect(){
		$mysqli = mysqli_connect("localhost", "root", "root", "Immigration");
		if (mysqli_connect_errno($mysqli)) {
			echo("report_Connect_Error");
		}else{Distrubutor();}	
} 



 
function MakeDialog(){
	 	echo 
	 	"
	 	<div id='dialog-report-error' style='display:none;'>
	 	<p>
	 	<img src='img/robot.png' width='60' height='60'>OOPS! There was an error.</p>
	 	</div>
	 	";
}

?>