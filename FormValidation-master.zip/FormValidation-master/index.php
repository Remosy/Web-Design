<html class="no-js" lang="en">
<head>
<meta charset="utf-8"/>
<meta http-equiv="CACHE-CONTROL" content="no-cache">
<meta name="author" content="TheImmigration">
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<link rel="stylesheet" href="css/jquery-ui.css">
<link rel="stylesheet" href="css/form.css"> 
<script src="https://code.jquery.com/jquery-2.2.3.min.js"></script>
<!--<script src="js/jquery.js"></script>-->
<script src="js/jquery-ui.js"></script>
<!-- Notification -->
<script src="js/form.js"></script>
<script src="js/connect.js"></script>
<title>Form</title>
</head>
<?php
	include 'connector.php';
	echo($run);
?>
<body style="background-color: #f5f5f0;margin: 0;">
	<form id="remyform">
		<section>
			<label for="otherName">Other Name</label>
			<input type="text" name="otherName" id="otherName" maxlength="25" title="Optional" onkeyup="checkInjection(this)"/>
		</section>
		
		<section>
			<label for="lastName">Last Name</label>
			<input type="text" name="lastName" id="lastName" maxlength="25" title="Optional" onkeyup="checkInjection(this)"/>
		</section>
		
		<section>
			<label for="year">Years</label>
			<input type="text" name="year" id="year" style="border:0;" title="Optional"/>
			<div id="yearRange"></div>

		</section>
		
		<section>
			<label for="from">From</label>
			<input type="text" name="from" id="from" maxlength="5" placeholder="day-month" title="Optional" onkeyup="checkDate(this)"/>
		</section>
		
		<section>
			<label for="to">To</label>
			<input type="text" name="to" id="to" maxlength="5" placeholder="day-month" title="Optional" onkeyup="checkDate(this)"/>
		</section>
		
		<section>
			<label for="shipName">Ship Name</label>
			<input type="text" name="shipName" id="shipName" maxlength="25" title="Optional" onkeyup="checkInjection(this)"/>
		</section>
		
		<section>
			<label for="age">Age</label>
			<input type="text" name="age" id="age" maxlength="3" title="Optional" placeholder="eg. 18" onkeyup="checkInjection(this)"/>
		</section>
		
		<section>
			<label for="applicant">Applicant</label>
			<input type="text" name="applicant" id="applicant" maxlength="25" title="Optional" onkeyup="checkInjection(this)"/>
		</section>
		
		<section>
			<label for="qsa_Item_ID">QSA Item ID</label>
			<input type="text" name="qsa_Item_ID" id="qsa_Item_ID" maxlength="10" title="Optional" placeholder="eg. 292922" onkeyup="checkInjection(this)"/>
		</section>
		
		<section>
			<label for="submit"></label>
			<input type="button" value="Search" name="submit" id="submit" onclick="userInput()"/>
		</section>
	</form>
	
	<?php
		MakeDialog();
	?>
</body>
</html>

