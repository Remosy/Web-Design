$(document).ready(function(){
	            /*
	            Animation -> Notifacation
            */       
            $(function() {
			    var tooltips = $( "[title]" ).tooltip({
			      position: {
			        my: "left top",
			        at: "right+5 top-5"
			      }
			    });
			}); 
			
			/*
	            Animation -> Year Slider 
            */
         
			$(function() {
			 	$( "#yearRange" ).slider({
			      range: true,
			      min: 1848,
			      max: 1917,
			      values: [ 1880, 1900 ],
			      slide: function( event, ui ) {
			        $( "#year" ).val( "" + ui.values[ 0 ] + " -- " + ui.values[ 1 ] );
			      }
			    });
			    $( "#year" ).val( "" + $( "#yearRange" ).slider( "values", 0 ) +
			      " -- " + $( "#yearRange" ).slider( "values", 1 ) );
			});
			        
            				
});
